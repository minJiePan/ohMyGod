package com.mediatek.filemanager.utils;

public interface Defs {
	
	public static String PATH_FLAG_ALL_FILES = "all files";
	public static String PATH_FLAG_PICTURE = "picture";
	public static String PATH_FLAG_VIDEO = "video";
	public static String PATH_FLAG_MUSIC = "music";
	public static String PATH_FLAG_DOCUMENT = "document";
	
	public static int POS_FLAG_ALL_FILES = 0;
	public static int POS_FLAG_PICTURE = 1;
	public static int POS_FLAG_VIDEO = 2;
	public static int POS_FLAG_MUSIC = 3;
	public static int POS_FLAG_DOCUMENT = 4;
	
	public static int REQUEST_CODE_NORMAL = 0;
	public static int REQUEST_CODE_SELECT_PATH_HOME = 1;
	public static int REQUEST_CODE_SELECT_PATH_PICTURE = 2;
	public static int REQUEST_CODE_SELECT_PATH_VIDEO = 3;
	public static int REQUEST_CODE_SELECT_PATH_MUSIC = 4;
	public static int REQUEST_CODE_SELECT_PATH_DOCUMENT = 5;
	public static int REQUEST_CODE_ADD_CATEGORY = 6;
	public static int REQUEST_CODE_GET_PASTE_PATH = 7;
}