package com.mediatek.filemanager.views;

public class MXEmptyView {
	
}