package com.mediatek.filemanager;

import java.io.File;

import com.mediatek.filemanager.utils.FileUtils;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

class detailsInfo {
	
}

public class DetailsAdapter extends BaseAdapter {
	
	public static final int MODE_FILE = 3;
	public static final int MODE_DIRECTORY = 4;
	private int mMode;
	private Context mContext;
    private final LayoutInflater mInflater;
    private FileInfo mFileInfo;
    public int cntFile, cntDir;
    public String mSize = "0B";
    
    public DetailsAdapter(Context context, FileInfo fileInfo) {
    	mContext = context;
    	mInflater = LayoutInflater.from(context);
    	mFileInfo = fileInfo;
    	cntFile = cntDir = 0;
    	if (!fileInfo.isDirectory()) return ;
    	for (File file:fileInfo.getFile().listFiles()) {
    		if (file.isDirectory())
    			cntDir++;
    		else
    			cntFile++;
    	}
    }
    
	public void setMode(int mode) {
		mMode = mode;
	}
	
	public int getMode() {
		return mMode;
	}
	
	@Override
	public int getCount() {
		return mMode;
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		TextView title, summary;
		View view = null;
		if (convertView == null) {
			view = mInflater.inflate(R.layout.details_item, null);
		} else {
			view = convertView;
		}
		
		title = (TextView) view.findViewById(R.id.title);
		summary = (TextView) view.findViewById(R.id.summary);
		
		switch (position) {
		case 0:
			title.setText(R.string.name);
			summary.setText(mFileInfo.getFileName());
			break;
		case 1:
			title.setText(R.string.size);
			summary.setText(mSize);
			break;
		case 2:
			title.setText(R.string.last_modified_time);
			summary.setText(FileUtils.formatDateString(mContext, mFileInfo.getFileLastModifiedTime()));
			break;
		case 3:
			title.setText(R.string.contents);
			StringBuilder builder = new StringBuilder();
			builder.append(mContext.getString(R.string.folder)).append(String.valueOf(cntDir))
			.append(",").append(mContext.getString(R.string.file)).append(String.valueOf(cntFile));
			summary.setText(builder.toString());
			break;
		default:
			break;
		}
		return view;
	}
}