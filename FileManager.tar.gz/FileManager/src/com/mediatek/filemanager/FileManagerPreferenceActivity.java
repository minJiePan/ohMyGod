package com.mediatek.filemanager;

import java.io.File;

import com.mediatek.filemanager.utils.Defs;

import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.preference.Preference.OnPreferenceClickListener;
import android.preference.PreferenceActivity;
import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.view.Menu;
import android.view.MenuItem;

public class FileManagerPreferenceActivity extends PreferenceActivity implements OnSharedPreferenceChangeListener, OnPreferenceClickListener{

	public static String KEY_SHOW_HIDEN_FILES = "show_hidden_files";
	public static String KEY_SHOW_FILE_EXTENSION = "show_file_extension";
	public static String KEY_SHOW_CATEGORY = "show_category";
	public static String KEY_HOME_DIRECTORY = "home_directory";
	public static String KEY_IMAGE_DIRECTORY = "image_directory";
	public static String KEY_VIDEO_DIRECTORY = "video_directory";
	public static String KEY_MUSIC_DIRECTORY = "music_directory";
	public static String KEY_DOCUMENT_DIRECTORY = "document_directory";
	
	private SharedPreferences share;
	
	private Preference preShowCategory;
	private Preference preHomeDirectory;
	private Preference preImageDirectory;
	private Preference preVideoDirectory;
	private Preference preMusicDirectory;
	private Preference preDocumentDirectory;
	private String primaryVolumePath = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		addPreferencesFromResource(R.xml.preferences);
		
        ActionBar actionBar = getActionBar();
        actionBar.setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP,
                ActionBar.DISPLAY_SHOW_CUSTOM | ActionBar.DISPLAY_HOME_AS_UP);
        
        share = getPreferenceScreen().getSharedPreferences();
        share.registerOnSharedPreferenceChangeListener(this);
        
        preShowCategory = findPreference(KEY_SHOW_CATEGORY);
        preShowCategory.setOnPreferenceClickListener(this);
        
        preHomeDirectory = findPreference(KEY_HOME_DIRECTORY);
        preImageDirectory = findPreference(KEY_IMAGE_DIRECTORY);
        preVideoDirectory = findPreference(KEY_VIDEO_DIRECTORY);
        preMusicDirectory = findPreference(KEY_MUSIC_DIRECTORY);
        preDocumentDirectory = findPreference(KEY_DOCUMENT_DIRECTORY);
        
        preHomeDirectory.setOnPreferenceClickListener(this);
        preImageDirectory.setOnPreferenceClickListener(this);
        preVideoDirectory.setOnPreferenceClickListener(this);
        preMusicDirectory.setOnPreferenceClickListener(this);
        preDocumentDirectory.setOnPreferenceClickListener(this);
        
        initSelectDirecories();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			setResult(RESULT_OK);
			finish();
			break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onSharedPreferenceChanged(SharedPreferences sharedPreferences,
			String key) {
		
	}

	@Override
	public boolean onPreferenceClick(Preference preference) {
		String forCase = preference.getKey();
		Intent intent = new Intent(FileManagerPreferenceActivity.this, FileManagerSelectPathActivity.class);
		if (forCase.equals(KEY_SHOW_CATEGORY)) {
			initSelectDirecories();
		} else if (forCase.equals(KEY_HOME_DIRECTORY)) {
			startActivityForResult(intent, Defs.REQUEST_CODE_SELECT_PATH_HOME);
		} else if (forCase.equals(KEY_IMAGE_DIRECTORY)) {
			startActivityForResult(intent, Defs.REQUEST_CODE_SELECT_PATH_PICTURE);
		} else if (forCase.equals(KEY_VIDEO_DIRECTORY)) {
			startActivityForResult(intent, Defs.REQUEST_CODE_SELECT_PATH_VIDEO);
		} else if (forCase.equals(KEY_MUSIC_DIRECTORY)) {
			startActivityForResult(intent, Defs.REQUEST_CODE_SELECT_PATH_MUSIC);
		} else if (forCase.equals(KEY_DOCUMENT_DIRECTORY)) {
			startActivityForResult(intent, Defs.REQUEST_CODE_SELECT_PATH_DOCUMENT);
		}
		
		return true;
	}
	
	public void initSelectDirecories() {  
        if (share.getBoolean(KEY_SHOW_CATEGORY, true)) {
        	preHomeDirectory.setEnabled(false);
            preImageDirectory.setEnabled(true);
            preVideoDirectory.setEnabled(true);
            preMusicDirectory.setEnabled(true);
            preDocumentDirectory.setEnabled(true);
        } else {
        	preHomeDirectory.setEnabled(true);
            preImageDirectory.setEnabled(false);
            preVideoDirectory.setEnabled(false);
            preMusicDirectory.setEnabled(false);
            preDocumentDirectory.setEnabled(false);
        }
        
        primaryVolumePath = MountPointManager.getInstance().getPrimaryVolumePath();
      
        String temp = share.getString(preHomeDirectory.getKey(), primaryVolumePath);
        preHomeDirectory.setSummary(temp);
        
        Editor editor = share.edit();
        temp = share.getString(preImageDirectory.getKey(), primaryVolumePath + "/DCIM");
        if ((new File(temp)).exists()){
        	preImageDirectory.setSummary(temp);
        	editor.putString(KEY_IMAGE_DIRECTORY, temp);
        } else{
        	preImageDirectory.setSummary(primaryVolumePath);
        }
        
        temp = share.getString(preVideoDirectory.getKey(), primaryVolumePath + "/DCIM");
        if ((new File(temp)).exists()) {
        	preVideoDirectory.setSummary(temp);
        	editor.putString(KEY_VIDEO_DIRECTORY, temp);
        } else {
        	preVideoDirectory.setSummary(primaryVolumePath);
        }
        
        temp = share.getString(preMusicDirectory.getKey(), primaryVolumePath + "/Music");
        if ((new File(temp)).exists()) {
        	preMusicDirectory.setSummary(temp);
        	editor.putString(KEY_MUSIC_DIRECTORY, temp);
        } else {
        	preMusicDirectory.setSummary(primaryVolumePath);
        }
        
        temp = share.getString(preDocumentDirectory.getKey(), primaryVolumePath + "/Documents");
        if ((new File(temp)).exists()) {
        	preDocumentDirectory.setSummary(temp);
        	editor.putString(KEY_DOCUMENT_DIRECTORY, temp);
        } else {
        	preDocumentDirectory.setSummary(primaryVolumePath);
        }
        editor.commit();
	}
	
	public static String getPath(String flagPath, Context context) {
		String primaryPath = MountPointManager.getInstance().getPrimaryVolumePath();
		SharedPreferences settingsShare = PreferenceManager.getDefaultSharedPreferences(context);
		Editor editor = settingsShare.edit();
		String ret = null;
		if (flagPath.equals(Defs.PATH_FLAG_ALL_FILES)) {
			ret = settingsShare.getString(KEY_HOME_DIRECTORY, primaryPath);
		} else if (flagPath.equals(Defs.PATH_FLAG_PICTURE)) {
			ret = settingsShare.getString(KEY_IMAGE_DIRECTORY, primaryPath + "/DCIM");
	        if ((new File(ret)).exists())
	        	editor.putString(KEY_IMAGE_DIRECTORY, ret);
	        else
	        	ret = primaryPath;
		} else if (flagPath.equals(Defs.PATH_FLAG_VIDEO)) {
			ret = settingsShare.getString(KEY_VIDEO_DIRECTORY, primaryPath + "/DCIM");
			if ((new File(ret)).exists())
		        editor.putString(KEY_VIDEO_DIRECTORY, ret);
			else
				ret = primaryPath;
		} else if (flagPath.equals(Defs.PATH_FLAG_MUSIC)) {
			ret = settingsShare.getString(KEY_MUSIC_DIRECTORY, primaryPath + "/Music");
			if ((new File(ret)).exists())
		        editor.putString(KEY_MUSIC_DIRECTORY, ret);
			else
				ret = primaryPath;
		} else if (flagPath.equals(Defs.PATH_FLAG_DOCUMENT)) {
			ret = settingsShare.getString(KEY_DOCUMENT_DIRECTORY, primaryPath + "/Documents");
			if ((new File(ret)).exists())
		        editor.putString(KEY_DOCUMENT_DIRECTORY, ret);
			else
				ret = primaryPath;
		}
		editor.commit();
		return ret;
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode != RESULT_OK) return ;
		Editor editor = share.edit();
		String path = data.getStringExtra(FileManagerSelectPathActivity.DOWNLOAD_PATH_KEY);
		switch (requestCode) {
		case Defs.REQUEST_CODE_SELECT_PATH_HOME:
			editor.putString(KEY_HOME_DIRECTORY, path);
			preHomeDirectory.setSummary(path);
			break;
		case Defs.REQUEST_CODE_SELECT_PATH_PICTURE:
			editor.putString(KEY_IMAGE_DIRECTORY, path);
			preImageDirectory.setSummary(path);
			break;
		case Defs.REQUEST_CODE_SELECT_PATH_VIDEO:
			editor.putString(KEY_VIDEO_DIRECTORY, path);
			preVideoDirectory.setSummary(path);
			break;
		case Defs.REQUEST_CODE_SELECT_PATH_MUSIC:
			editor.putString(KEY_MUSIC_DIRECTORY, path);
			preMusicDirectory.setSummary(path);
			break;
		case Defs.REQUEST_CODE_SELECT_PATH_DOCUMENT:
			editor.putString(KEY_DOCUMENT_DIRECTORY, path);
			preDocumentDirectory.setSummary(path);
			break;
		default:
			break;
		}
		editor.commit();
		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	public void onBackPressed() {
		setResult(RESULT_OK);
		super.onBackPressed();
	}
	
	public static boolean getOptionalHide(Context context) {
		SharedPreferences share = PreferenceManager.getDefaultSharedPreferences(context);
		return share.getBoolean(KEY_SHOW_HIDEN_FILES, false);
	}
	
	public static boolean getOptionalExtension(Context context) {
		SharedPreferences share = PreferenceManager.getDefaultSharedPreferences(context);
		return share.getBoolean(KEY_SHOW_FILE_EXTENSION, true);
	}
	
	public static boolean getOptionalCategory(Context context) {
		SharedPreferences share = PreferenceManager.getDefaultSharedPreferences(context);
		return share.getBoolean(KEY_SHOW_CATEGORY, true);
	}
	 
	public static String getOptionalHomeDirectory(Context context) {
		String primaryPath = MountPointManager.getInstance().getPrimaryVolumePath();
		SharedPreferences share = PreferenceManager.getDefaultSharedPreferences(context);
		return share.getString(KEY_HOME_DIRECTORY, primaryPath);
	}
}
