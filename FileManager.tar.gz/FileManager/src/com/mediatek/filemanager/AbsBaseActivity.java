/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 * 
 * MediaTek Inc. (C) 2010. All rights reserved.
 * 
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

/*
 * fileobserver:可以观察某个文件的变化
 */
package com.mediatek.filemanager;

import android.app.ActionBar;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Scroller;
import android.widget.TextView;

import com.mediatek.filemanager.AlertDialogFragment.EditDialogFragmentBuilder;
import com.mediatek.filemanager.AlertDialogFragment.EditTextDialogFragment;
import com.mediatek.filemanager.AlertDialogFragment.OnDialogDismissListener;
import com.mediatek.filemanager.AlertDialogFragment.EditTextDialogFragment.EditTextDoneListener;
import com.mediatek.filemanager.FileInfoManager.NavigationRecord;
import com.mediatek.filemanager.MountReceiver.MountListener;
import com.mediatek.filemanager.service.FileManagerService;
import com.mediatek.filemanager.service.FileManagerService.ServiceBinder;
import com.mediatek.filemanager.service.ProgressInfo;
import com.mediatek.filemanager.utils.FileUtils;
import com.mediatek.filemanager.utils.LogUtils;
import com.mediatek.filemanager.utils.ToastHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * This is the base activity for FileInfoManager(Activity), SelectFileActivity,
 * SelectPathActivity, SearchActivity. It defines the basic views and
 * interactions for activities.
 */
public abstract class AbsBaseActivity extends Activity implements OnItemClickListener,
        OnClickListener, MountListener, OnDialogDismissListener {
    private static final String TAG = "AbsBaseActivity";
    public static final String SAVED_PATH_KEY = "saved_path";
    private static final long NAV_BAR_AUTO_SCROLL_DELAY = 100;
    /** maximum tab text length */
    private static final int TAB_TEXT_LENGTH = 11;

    protected static final int DIALOG_CREATE_FOLDER = 1;

    /** ListView used for showing Files */
    protected ListView mListView = null;
    protected FileInfoAdapter mAdapter = null;
    protected TabManager mTabManager = null;
    protected TextView mNavigationBar = null;
    protected FileInfo mSelectedFileInfo = null;
    protected MountPointManager mMountPointManager = null;
    protected MountReceiver mMountReceiver = null;

    protected FileManagerService mService = null;
    protected int mTop = -1;
    protected int mSortType = 0;
    protected int mViewByType = 0;
    protected String mCurrentPath = null;
    protected ToastHelper mToastHelper = null;
    protected FileInfoManager mFileInfoManager = null;
    public static final String CREATE_FOLDER_DIALOG_TAG = "CreateFolderDialog";
    protected Bundle mSavedInstanceState = null;

    public static final int MSG_DO_MOUNTED = 0;
    public static final int MSG_DO_EJECTED = 1;
    public static final int MSG_DO_UNMOUNTED = 2;

    protected boolean mIsAlertDialogShowing = false;
    public boolean needToInitAction = false;
    
    public int showOptionals = FileManagerService.FILE_FILTER_TYPE_SHOW_ALL;
    
    // there should always be only one dialog showing, to control it by this
    // flag, see ALPS00428101
    @Override
    public void onDialogDismiss() {
        LogUtils.d(TAG, "dialog dismissed...");
        mIsAlertDialogShowing = false;
    }

    private final ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mService.disconnected(this.getClass().getName());
            LogUtils.w(TAG, "onServiceDisconnected");
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            LogUtils.d(TAG, "onServiceConnected");
            mService = ((ServiceBinder) service).getServiceInstance();
            serviceConnected();
        }
    };

    private Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            LogUtils.d(TAG, "handleMessage, msg = " + msg.what);
            switch (msg.what) {
            case MSG_DO_MOUNTED:
                doOnMounted((String) msg.obj);
                break;
            case MSG_DO_EJECTED:
                doOnEjected((String) msg.obj);
                break;
            case MSG_DO_UNMOUNTED:
                doOnUnMounted((String) msg.obj);
                break;
            default:
                break;
            }
        }
    };

    private void doPrepareForMount(String mountPoint) {
        LogUtils.i(TAG, "doPrepareForMount,mountPoint = " + mountPoint);
        if ((mCurrentPath + MountPointManager.SEPARATOR).startsWith(mountPoint
                + MountPointManager.SEPARATOR)
                || mMountPointManager.isRootPath(mCurrentPath)) {
            LogUtils.d(TAG, "pre-onMounted");
            if (mService != null && mService.isBusy(this.getClass().getName())) {
                mService.cancel(this.getClass().getName());
            }
        }

        mMountPointManager.init(getApplicationContext());
    }

    @Override
    public void onMounted(String mountPoint) {
        LogUtils.i(TAG, "onMounted,mountPoint = " + mountPoint);
        Message.obtain(mHandler, MSG_DO_MOUNTED, mountPoint).sendToTarget();
    }

    private void doOnMounted(String mountPoint) {
        LogUtils.i(TAG, "doOnMounted,mountPoint = " + mountPoint);
        doPrepareForMount(mountPoint);
        if (mMountPointManager.isRootPath(mCurrentPath)) {
            LogUtils.d(TAG, "doOnMounted,mCurrentPath is root path: " + mCurrentPath);
            showDirectoryContent(mCurrentPath);
        }
    }

    @Override
    public void onUnMounted(String unMountPoint) {
        LogUtils.i(TAG, "onUnMounted,unMountPoint: " + unMountPoint);
        Message.obtain(mHandler, MSG_DO_UNMOUNTED, unMountPoint).sendToTarget();
    }

    @Override
    public void onEjected(String unMountPoint) {
        LogUtils.i(TAG, "onEjected,unMountPoint: " + unMountPoint);
        Message.obtain(mHandler, MSG_DO_EJECTED, unMountPoint).sendToTarget();
    }

    private void doOnEjected(String unMountPoint) {
        if ((mCurrentPath + MountPointManager.SEPARATOR).startsWith(unMountPoint
                + MountPointManager.SEPARATOR)
                || mMountPointManager.isRootPath(mCurrentPath)
                || mMountPointManager.isPrimaryVolume(unMountPoint)) {
            LogUtils.d(TAG, "onEjected,Current Path = " + mCurrentPath);
            if (mService != null && mService.isBusy(this.getClass().getName())) {
                mService.cancel(this.getClass().getName());
            }
        }
    }

    private void doOnUnMounted(String unMountPoint) {
        if (mFileInfoManager != null) {
            int pasteCnt = mFileInfoManager.getPasteCount();
            LogUtils.i(TAG, "doOnUnmounted,unMountPoint: " + unMountPoint + ",pasteCnt = "
                    + pasteCnt);

            if (pasteCnt > 0) {
                FileInfo fileInfo = mFileInfoManager.getPasteList().get(0);
                if (fileInfo.getFileAbsolutePath().startsWith(
                        unMountPoint + MountPointManager.SEPARATOR)) {
                    LogUtils.i(TAG, "doOnUnmounted,clear paste list. ");
                    mFileInfoManager.clearPasteList();
                    invalidateOptionsMenu();
                }
            }
        }

        if ((mCurrentPath + MountPointManager.SEPARATOR).startsWith(unMountPoint
                + MountPointManager.SEPARATOR)
                || mMountPointManager.isRootPath(mCurrentPath)) {
            LogUtils.d(TAG, "onUnmounted,Current Path = " + mCurrentPath);
            if (mService != null && mService.isBusy(this.getClass().getName())) {
                mService.cancel(this.getClass().getName());
            }
            showToastForUnmount(unMountPoint);

            DialogFragment listFramgent = (DialogFragment) getFragmentManager().findFragmentByTag(
                    ListListener.LIST_DIALOG_TAG);
            if (listFramgent != null) {
                LogUtils.d(TAG, "onUnmounted,listFramgent dismiss. ");
                listFramgent.dismissAllowingStateLoss();
            }

            EditTextDialogFragment createFolderDialogFragment = (EditTextDialogFragment) getFragmentManager()
                    .findFragmentByTag(CREATE_FOLDER_DIALOG_TAG);
            if (createFolderDialogFragment != null) {
                LogUtils.d(TAG, "onUnmounted,createFolderDialogFragment dismiss. ");
                createFolderDialogFragment.dismissAllowingStateLoss();
            }

            backToRootPath();
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mSavedInstanceState = savedInstanceState;

        LogUtils.d(TAG, "onCreate");

        mToastHelper = new ToastHelper(this);
        // start watching external storage change.
        mMountPointManager = MountPointManager.getInstance();
        mMountPointManager.init(getApplicationContext());

        bindService(new Intent(getApplicationContext(), FileManagerService.class),
                mServiceConnection, BIND_AUTO_CREATE);

        setMainContentView();

        // set up a sliding navigation bar for navigation view
        mNavigationBar = (TextView) findViewById(R.id.navigation_bar);
        if (mNavigationBar != null) {
//            mNavigationBar.setVerticalScrollBarEnabled(false);
//            mNavigationBar.setHorizontalScrollBarEnabled(false);
            mTabManager = new TabManager();
        }

        // set up a list view
        mListView = (ListView) findViewById(R.id.list_view);
        if (mListView != null) {
            mListView.setEmptyView(findViewById(R.id.empty_view));
            mListView.setOnItemClickListener(this);
            //mListView.setFastScrollEnabled(true);
            // mListView.setVerticalScrollBarEnabled(false);
            mListView.setVerticalScrollBarEnabled(true);
        }
    }

    private void reloadContent() {
        LogUtils.d(TAG, "reloadContent");
        if (mService != null && !mService.isBusy(this.getClass().getName())) {
            if (mFileInfoManager != null && mFileInfoManager.isPathModified(mCurrentPath)) {
                showDirectoryContent(mCurrentPath);
            } else if (mFileInfoManager != null && mAdapter != null) {
                for (int i = 0; i < mAdapter.getCount(); i++) {
                    if (mAdapter.getItem(i).isDrmFile()) {
                        mAdapter.notifyDataSetChanged();
                        break;
                    }
                }
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        LogUtils.d(TAG, "onResume");
        reloadContent();
    }

    protected void showCreateFolderDialog() {
        LogUtils.d(TAG, "showCreateFolderDialog");
        if (mIsAlertDialogShowing) {
            LogUtils.d(TAG, "Another Dialog showing, return!~~");
            return;
        }
        mIsAlertDialogShowing = true;
        EditDialogFragmentBuilder builder = new EditDialogFragmentBuilder();
        builder.setDefault("", 0).setDoneTitle(R.string.ok).setCancelTitle(R.string.cancel)
                .setTitle(R.string.new_folder);
        EditTextDialogFragment createFolderDialogFragment = builder.create();
        createFolderDialogFragment.setOnEditTextDoneListener(new CreateFolderListener());
        createFolderDialogFragment.setOnDialogDismissListener(this);
        createFolderDialogFragment.show(getFragmentManager(), CREATE_FOLDER_DIALOG_TAG);
    }

    protected final class CreateFolderListener implements EditTextDoneListener {
        public void onClick(String text) {
            if (mService != null) {
                String dstPath = mCurrentPath + MountPointManager.SEPARATOR + text;
                mService.createFolder(AbsBaseActivity.this.getClass().getName(), dstPath,
                        new LightOperationListener(text));
            }
        }
    }

    /**
     * This method is left for its children class to set main layout
     */
    protected abstract void setMainContentView();

    @Override
    protected void onDestroy() {
        LogUtils.d(TAG, "onDestroy");
        if (mService != null) {
            unbindService(mServiceConnection);
        }

        mMountReceiver.unregisterMountListener(this);
        unregisterReceiver(mMountReceiver);

        super.onDestroy();
    }

    private void backToRootPath() {
        LogUtils.d(TAG, "backToRootPath...");
        if (mMountPointManager != null && mMountPointManager.isRootPath(mCurrentPath)) {
            showDirectoryContent(mCurrentPath);
        } else if (mTabManager != null) {
            mTabManager.updateNavigationBar(0);
        }
        clearNavigationList();
    }

    private void showToastForUnmount(String path) {
        LogUtils.d(TAG, "showToastForUnmount,path = " + path);
        if (isResumed()) {
            String unMountPointDescription = MountPointManager.getInstance().getDescriptionPath(
                    path);
            LogUtils.d(TAG, "showToastForUnmount,unMountPointDescription:"
                    + unMountPointDescription);
            mToastHelper.showToast(getString(R.string.unmounted, unMountPointDescription));
        }
    }

    /**
     * This method add a path into navigation history list
     * 
     * @param dirPath
     *            the path that should be added
     */
    protected void addToNavigationList(String path, FileInfo selectedFileInfo, int top) {
        mFileInfoManager.addToNavigationList(new NavigationRecord(path, selectedFileInfo, top));
    }

    /**
     * This method clear navigation history list
     */
    protected void clearNavigationList() {
        mFileInfoManager.clearNavigationList();
    }

    /**
     * This method used to be inherited by subclass to get a path.
     * 
     * @return path to a folder
     */
    protected abstract String initCurrentFileInfo();

    protected class TabManager {
        private final List<String> mTabNameList = new ArrayList<String>();
        protected LinearLayout mTabsHolder = null;
        private String mCurFilePath = null;
        private Button mBlankTab;

        public TabManager() {
        }

        public void refreshTab(String initFileInfo) {
            LogUtils.d(TAG, "refreshTab,initFileInfo = " + initFileInfo);
            mTabNameList.clear();
            mCurFilePath = initFileInfo;
            if (mCurFilePath != null) {
            	if (initFileInfo.equals(MountPointManager.CATEGORY_PATH)) return;
                mNavigationBar.setText(initFileInfo);
            }
        }

        /**
         * This method updates the navigation view to the previous view when
         * back button is pressed
         * 
         * @param newPath
         *            the previous showed directory in the navigation history
         */
        private void showPrevNavigationView(String newPath) {

            refreshTab(newPath);
            showDirectoryContent(newPath);
        }

        /**
         * This method creates tabs on the navigation bar
         * 
         * @param text
         *            the name of the tab
         */
        protected void addTab(String text) {
            mTabNameList.add(text);
        	mNavigationBar.setText(mNavigationBar.getText() + "/" + text);
        }

        /**
         * The method updates the navigation bar
         * 
         * @param id
         *            the tab id that was clicked
         */
        protected void updateNavigationBar(int id) {
            LogUtils.d(TAG, "updateNavigationBar,id = " + id);
            // click current button do not response
            if (id < mTabNameList.size() - 1) {
                int count = mTabNameList.size() - id;

                for (int i = 1; i < count; i++) {
                    // update mTabNameList
                    mTabNameList.remove(mTabNameList.size() - 1);
                }

                if (id == 0) {
                    mCurFilePath = mMountPointManager.getRootPath();
                } else {
                    String[] result = mCurFilePath.split(MountPointManager.SEPARATOR);
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i <= id; i++) {
                        sb.append(MountPointManager.SEPARATOR);
                        sb.append(result[i + 1]);
                    }
                    mCurFilePath = sb.toString();
                }
                
                int top = -1;
                FileInfo selectedFileInfo = null;
                if (mListView.getCount() > 0) {
                    View view = mListView.getChildAt(0);
                    selectedFileInfo = mAdapter.getItem(mListView.getPositionForView(view));
                    top = view.getTop();
                }
                addToNavigationList(mCurrentPath, selectedFileInfo, top);
                showDirectoryContent(mCurFilePath);
            }
        }

    }

    @Override
    public void onClick(View view) {
        if (mService.isBusy(this.getClass().getName())) {
            LogUtils.d(TAG, "onClick(), service is busy.");
            return;
        }
        int id = view.getId();
        LogUtils.d(TAG, "onClick() id=" + id);
        mTabManager.updateNavigationBar(id);
    }

    private int restoreSelectedPosition() {
        if (mSelectedFileInfo == null) {
            return -1;
        } else {
            int curSelectedItemPosition = mAdapter.getPosition(mSelectedFileInfo);
            mSelectedFileInfo = null;
            return curSelectedItemPosition;
        }
    }

    /**
     * This method gets all files/folders from a directory and displays them in
     * the list view
     * 
     * @param dirPath
     *            the directory path
     */
    protected void showDirectoryContent(String path) {
        LogUtils.d(TAG, "showDirectoryContent,path = " + path);
        if (isFinishing()) {
            LogUtils.i(TAG, "showDirectoryContent,isFinishing: true, do not loading again");
            return;
        }
        mCurrentPath = path;
        initAction();
        
        if (mService != null) {
            mService.listFiles(this.getClass().getName(), mCurrentPath, new ListListener());
        }
    }
    
	public void initAction() {
		ActionBar bar = getActionBar();
		if (!MountPointManager.getInstance().isCategoryPath(mCurrentPath)) {
			bar.setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP, ActionBar.DISPLAY_HOME_AS_UP);
		} else {
			bar.setDisplayOptions(0, ActionBar.DISPLAY_HOME_AS_UP);
			bar.setHomeButtonEnabled(false);
		}
		
		if (MountPointManager.getInstance().isCategoryPath(mCurrentPath)) {
			bar.setTitle(R.string.app_name);
			return ;
		}
		
		switch (FileUtils.high28Bit(showOptionals)) {
		case FileManagerService.FILE_FILTER_TYPE_SHOW_ALL:
			bar.setTitle(R.string.app_name);
			break;
		case FileManagerService.FILE_FILTER_TYPE_SHOW_PICITURE:
			bar.setTitle(R.string.images);
			break;
		case FileManagerService.FILE_FILTER_TYPE_SHOW_VIDEO:
			bar.setTitle(R.string.videos);
			break;
		case FileManagerService.FILE_FILTER_TYPE_SHOW_MUSIC:
			bar.setTitle(R.string.music);
			break;
		case FileManagerService.FILE_FILTER_TYPE_SHOW_DOCUMENT:
			bar.setTitle(R.string.documents);
			break;
		}
    }
	
    protected void onPathChanged() {
        LogUtils.d(TAG, "onPathChanged");
        if (mTabManager != null) {
            mTabManager.refreshTab(mCurrentPath);
        }
        invalidateOptionsMenu();
        if (MountPointManager.getInstance().isCategoryPath(mCurrentPath)) {
        	mNavigationBar.setVisibility(View.GONE);
        } else {
        	mNavigationBar.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onBackPressed() {
        LogUtils.d(TAG, "onBackPressed");
        if (mService != null && mService.isBusy(this.getClass().getName())) {
            LogUtils.i(TAG, "onBackPressed, service is busy. ");
            return;
        }
        boolean temp =FileManagerPreferenceActivity.getOptionalCategory(this);
        if (mCurrentPath != null && (!temp && !mMountPointManager.isRootPath(mCurrentPath) ||
        		temp && !mMountPointManager.isCategoryPath(mCurrentPath) )) {
            NavigationRecord navRecord = mFileInfoManager.getPrevNavigation();
            String prevPath = null;
            if (navRecord != null) {
                prevPath = navRecord.getRecordPath();
                mSelectedFileInfo = navRecord.getSelectedFile();
                mTop = navRecord.getTop();
                if (prevPath != null) {
                    mTabManager.showPrevNavigationView(prevPath);
                    LogUtils.d(TAG, "sonBackPressed,prevPath = " + prevPath);
                    return;
                }
            }
        }
        super.onBackPressed();
    }

    protected void serviceConnected() {
        LogUtils.i(TAG, "serviceConnected");

        mFileInfoManager = mService.initFileInfoManager(this.getClass().getName());
        mAdapter = new FileInfoAdapter(AbsBaseActivity.this, mService, mFileInfoManager);
        if (mListView != null) {
            mListView.setAdapter(mAdapter);

            if (mSavedInstanceState == null) {
                mCurrentPath = initCurrentFileInfo();
                if (mCurrentPath != null) {
                    showDirectoryContent(mCurrentPath);
                }
            } else {
                String savePath = mSavedInstanceState.getString(SAVED_PATH_KEY);
                if (savePath != null
                        && mMountPointManager.isMounted(mMountPointManager
                                .getRealMountPointPath(savePath))) {
                    mCurrentPath = savePath;
                } else {
                    mCurrentPath = initCurrentFileInfo();
                }

                if (mCurrentPath != null) {
                    mTabManager.refreshTab(mCurrentPath);
                    reloadContent();
                }
                restoreDialog();

            }
            mAdapter.notifyDataSetChanged();
        }
        // register Receiver when service connected..
        mMountReceiver = MountReceiver.registerMountReceiver(this);
        mMountReceiver.registerMountListener(this);
    }

    protected void restoreDialog() {
        DialogFragment listFramgent = (DialogFragment) getFragmentManager().findFragmentByTag(
                ListListener.LIST_DIALOG_TAG);
        if (listFramgent != null) {
            LogUtils.i(TAG, "listFramgent != null");
            if (mService.isBusy(this.getClass().getName())) {
                LogUtils.i(TAG, "list reconnected mService");
                mService.reconnected(this.getClass().getName(), new ListListener());
            } else {
                LogUtils.i(TAG, "the list is complete dismissAllowingStateLoss");
                listFramgent.dismissAllowingStateLoss();
            }
        }
        EditTextDialogFragment createFolderDialogFragment = (EditTextDialogFragment) getFragmentManager()
                .findFragmentByTag(CREATE_FOLDER_DIALOG_TAG);
        if (createFolderDialogFragment != null) {
            createFolderDialogFragment.setOnEditTextDoneListener(new CreateFolderListener());
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (mCurrentPath != null) {
            outState.putString(SAVED_PATH_KEY, mCurrentPath);
        }
        super.onSaveInstanceState(outState);
    }

    protected class ListListener implements FileManagerService.OperationEventListener {

        public static final String LIST_DIALOG_TAG = "ListDialogFragment";

        protected void dismissDialogFragment() {
            LogUtils.d(TAG, "ListListener dismissDialogFragment");
            DialogFragment listDialogFragment = (DialogFragment) getFragmentManager()
                    .findFragmentByTag(LIST_DIALOG_TAG);
            if (listDialogFragment != null) {
                LogUtils.d(TAG, "ListListener listDialogFragment != null dismiss");
                listDialogFragment.dismissAllowingStateLoss();
            }
        }

        @Override
        public void onTaskResult(int result) {
            LogUtils.i(TAG, "ListListener,TaskResult result = " + result);
            mFileInfoManager.loadFileInfoList(mCurrentPath, mSortType);
            mAdapter.notifyDataSetChanged();
            int seletedItemPosition = restoreSelectedPosition();
            if (seletedItemPosition == -1) {
                mListView.setSelectionAfterHeaderView();
            } else if (seletedItemPosition >= 0 && seletedItemPosition < mAdapter.getCount()) {
                if (mTop == -1) {
                    mListView.setSelection(seletedItemPosition);
                } else {
                    mListView.setSelectionFromTop(seletedItemPosition, mTop);
                    mTop = -1;
                }
            }
            dismissDialogFragment();
            onPathChanged();
            mListView.setVisibility(View.VISIBLE);
            // LogUtils.performance("Loading 10000files end [" +
            // System.currentTimeMillis() + "]");
        }

        @Override
        public void onTaskPrepare() {
            return;
        }

        @Override
        public void onTaskProgress(ProgressInfo progressInfo) {
            ProgressDialogFragment listDialogFragment = (ProgressDialogFragment) getFragmentManager()
                    .findFragmentByTag(LIST_DIALOG_TAG);
            if (isResumed()) {
                if (listDialogFragment == null) {
                    listDialogFragment = ProgressDialogFragment.newInstance(
                            ProgressDialog.STYLE_HORIZONTAL, -1, R.string.loading,
                            AlertDialogFragment.INVIND_RES_ID);

                    listDialogFragment.show(getFragmentManager(), LIST_DIALOG_TAG);
                    getFragmentManager().executePendingTransactions();
                }
                listDialogFragment.setProgress(progressInfo);
            }
        }
    }

    protected class LightOperationListener implements FileManagerService.OperationEventListener {

        String mDstName = null;

        LightOperationListener(String dstName) {
            mDstName = dstName;
        }

        @Override
        public void onTaskResult(int errorType) {
            LogUtils.i(TAG, "LightOperationListener,TaskResult result = " + errorType);
            switch (errorType) {
            case ERROR_CODE_SUCCESS:
            case ERROR_CODE_USER_CANCEL:
                FileInfo fileInfo = mFileInfoManager.updateOneFileInfoList(mCurrentPath, mSortType);
                mAdapter.notifyDataSetChanged();
                if (fileInfo != null) {
                    int postion = mAdapter.getPosition(fileInfo);
                    LogUtils.d(TAG, "LightOperation postion = " + postion);
                    mListView.setSelection(postion);
                    invalidateOptionsMenu();
                }
                break;
            case ERROR_CODE_FILE_EXIST:
                if (mDstName != null) {
                    mToastHelper.showToast(getResources().getString(R.string.already_exists,
                            mDstName));
                }
                break;
            case ERROR_CODE_NAME_EMPTY:
                mToastHelper.showToast(R.string.invalid_empty_name);
                break;
            case ERROR_CODE_NAME_TOO_LONG:
                mToastHelper.showToast(R.string.file_name_too_long);
                break;
            case ERROR_CODE_NOT_ENOUGH_SPACE:
                mToastHelper.showToast(R.string.insufficient_memory);
                break;
            case ERROR_CODE_UNSUCCESS:
                mToastHelper.showToast(R.string.operation_fail);
                break;
            default:
                LogUtils.e(TAG, "wrong errorType for LightOperationListener");
                break;
            }
        }

        @Override
        public void onTaskPrepare() {
            return;
        }

        @Override
        public void onTaskProgress(ProgressInfo progressInfo) {
            return;
        }
    }

    /**
     * This class add a slow-slide animation for HorizontalscrollView.
     */
    private static class SlowHorizontalScrollView extends HorizontalScrollView {
        private static final String TAG = "SlowHorizontalScrollView";
        private static final int SCROLL_DURATION = 2000;
        private final Scroller mScroller = new Scroller(getContext());

        public SlowHorizontalScrollView(Context context, AttributeSet attrs, int defStyle) {
            super(context, attrs, defStyle);
        }

        public SlowHorizontalScrollView(Context context) {
            super(context);
        }

        public SlowHorizontalScrollView(Context context, AttributeSet attrs) {
            super(context, attrs);
        }

        public void startHorizontalScroll(int startX, int dx) {
            LogUtils.d(TAG, "start scroll");
            mScroller.startScroll(startX, 0, dx, 0, SCROLL_DURATION);
            invalidate();
        }

        @Override
        public void computeScroll() {
            if (mScroller.computeScrollOffset()) {
                scrollTo(mScroller.getCurrX(), 0);
                postInvalidate();
            }
            super.computeScroll();
        }

        @Override
        public boolean onTouchEvent(MotionEvent ev) {
            mScroller.abortAnimation();
            return super.onTouchEvent(ev);
        }
    }
}
